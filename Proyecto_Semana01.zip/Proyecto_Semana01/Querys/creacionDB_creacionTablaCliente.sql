create database Sistema_Gerardo_DB
use Sistema_Gerardo_DB

CREATE TABLE CLIENTES (
idCliente int primary key AUTO_INCREMENT,
nombre varchar(30) not null,
apellido varchar (30) not null,
dni varchar (10) not null unique,
email varchar(50) not null,
CONSTRAINT chk_email CHECK (email REGEXP '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
)

select * from clientes



