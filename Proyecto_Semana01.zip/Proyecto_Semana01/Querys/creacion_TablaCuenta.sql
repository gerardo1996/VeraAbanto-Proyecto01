
use Sistema_Gerardo_DB

CREATE TABLE CUENTAS (
idCuenta int primary key AUTO_INCREMENT,
numero varchar(30) not null unique,
saldo decimal(10.2) not null,
tipodecuenta ENUM('Ahorros', 'Corriente') not null,
clienteid int not null,
CONSTRAINT chk_tipodecuenta CHECK (tipodecuenta IN ('Ahorros', 'Corriente'))
)

select * from cuentas
