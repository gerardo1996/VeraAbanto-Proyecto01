package com.nttdata.Proyectodos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectodosApplicationTests {

	@Test
	void contextLoads() {
	}

}
