package com.nttdata.Proyectodos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectodosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectodosApplication.class, args);
	}

}
