package com.nttdata.Proyectodos.business;

import com.nttdata.Proyectodos.model.CuentaRequest;
import com.nttdata.Proyectodos.model.entity.Cuentas;
import org.springframework.stereotype.Component;

@Component
public class CuentasMapper {

    public Cuentas getCuentasEntity (CuentaRequest request){
        Cuentas entity = new Cuentas();
        entity.setNumero(request.getNumero());
        entity.setSaldo(request.getSaldo());
        entity.setTipodecuenta(request.getTipodecuenta());
        entity.setClienteid(request.getClienteid());
        return entity;
    }

    public CuentaRequest getCuentasRequest (Cuentas entity) {
        CuentaRequest request = new CuentaRequest();
        request.setNumero(entity.getNumero());
        request.setSaldo(entity.getSaldo());
        request.setTipodecuenta(entity.getTipodecuenta());
        request.setClienteid(entity.getClienteid());
        return request;


    }

}
