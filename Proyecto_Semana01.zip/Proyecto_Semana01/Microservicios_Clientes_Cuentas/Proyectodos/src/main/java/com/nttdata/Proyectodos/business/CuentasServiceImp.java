package com.nttdata.Proyectodos.business;


import com.nttdata.Proyectodos.model.CuentaRequest;
import com.nttdata.Proyectodos.repository.CuentasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CuentasServiceImp implements CuentasService {

    @Autowired
    CuentasRepository cuentasRepository;

    @Autowired
    CuentasMapper cuentasMapper;

    @Override
    public List<CuentaRequest> listarCuenta() {
        return cuentasRepository.findAll().stream()
                .map(m -> cuentasMapper.getCuentasRequest(m))
                .collect(Collectors.toList());
    }

    @Override
    public CuentaRequest crearCuenta(CuentaRequest cuentaRequest) {
        return  cuentasMapper
                .getCuentasRequest(cuentasRepository.
                        save(cuentasMapper.getCuentasEntity(cuentaRequest)));
    }

    @Override
    public List<CuentaRequest> obtenerCuentasId() {
        return cuentasRepository.findAll().stream()
                .map(m -> cuentasMapper.getCuentasRequest(m))
                .filter(response -> "Corriente".equals(response.getTipodecuenta()))
                .collect(Collectors.toList());
    }

}
