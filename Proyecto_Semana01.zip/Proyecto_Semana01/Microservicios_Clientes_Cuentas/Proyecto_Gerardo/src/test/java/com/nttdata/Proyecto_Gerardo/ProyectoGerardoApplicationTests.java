package com.nttdata.Proyecto_Gerardo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoGerardoApplicationTests {

	@Test
	void contextLoads() {
	}

}
