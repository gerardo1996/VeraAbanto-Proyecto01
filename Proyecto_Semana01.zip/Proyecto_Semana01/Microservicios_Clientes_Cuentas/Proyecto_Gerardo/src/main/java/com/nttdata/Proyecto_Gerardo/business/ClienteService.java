
package com.nttdata.Proyecto_Gerardo.business;




import com.nttdata.Proyecto_Gerardo.model.ClienteRequest;

import java.util.List;

public interface ClienteService {

    public List<ClienteRequest> listarCliente();
    public  ClienteRequest crearCliente(ClienteRequest clienteRequest);
    public List<ClienteRequest>obtenerClientesId();
    public  ClienteRequest actualizarCliente(ClienteRequest clienteRequest);


    }