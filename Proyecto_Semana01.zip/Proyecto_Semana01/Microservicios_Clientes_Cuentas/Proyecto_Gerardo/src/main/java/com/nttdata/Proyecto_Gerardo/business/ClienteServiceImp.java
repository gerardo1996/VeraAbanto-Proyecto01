package com.nttdata.Proyecto_Gerardo.business;



import com.nttdata.Proyecto_Gerardo.model.ClienteRequest;
import com.nttdata.Proyecto_Gerardo.model.entity.Cliente;
import com.nttdata.Proyecto_Gerardo.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClienteServiceImp implements ClienteService {

    @Autowired
    ClienteRepository clienteRepositpory;

    @Autowired
    ClienteMapper clienteMapper;

    @Override
    public List<ClienteRequest> listarCliente() {
        return clienteRepositpory.findAll().stream()
                .map(m -> clienteMapper.getClienteRequest(m))
                .collect(Collectors.toList());
    }

    @Override
    public ClienteRequest crearCliente(ClienteRequest clienteRequest) {
        return  clienteMapper
                .getClienteRequest(clienteRepositpory.
                        save(clienteMapper.getClienteEntity(clienteRequest)));
    }

    @Override
    public List<ClienteRequest> obtenerClientesId() {
        return clienteRepositpory.findAll().stream()
                .map(m -> clienteMapper.getClienteRequest(m))
                .filter(response -> "Gerardo".equals(response.getNombre()))
               .collect(Collectors.toList());


    }

    @Override
    public ClienteRequest actualizarCliente(ClienteRequest clienteRequest) {
        return clienteMapper
                .getClienteRequest(clienteRepositpory.
                        save(clienteMapper.getClienteEntity(clienteRequest)));
    }


}